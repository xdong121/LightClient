(function () {
    "use strict";

    var moduleId = "Legacy.features.lightManage.tempTimeSchDetail.services";
    angular.module(moduleId, ["ngResource"]);

    angular.module(moduleId).factory('tempTimeSchDetailSvc', tempTimeSchDetailSvc);

    function tempTimeSchDetailSvc($resource) {
        return {
            crud: $resource("/api/tempTimeSchDetail/:id", {
                id: '@id'
            }, {
                'update': {
                    method: 'PUT'
                },
                'remove': {
                    method: 'DELETE'
                }
            }),
            BySelect: $resource("/api/tempTimeSchDetail/BySelect/:obj"),
            SelcetDetail: $resource("/api/TempTimeSchMain/SelcetDetail/:mid"),
        };
    }
   

}());