(function () {
    'use strict';

    angular.module('Legacy.features.lightManage.tempTimeSchDetail', [
        'Legacy.features.lightManage.tempTimeSchDetail.services'
    ]).config(routeConfig);

    function routeConfig($stateProvider, baSidebarServiceProvider) {
        $stateProvider
            .state('lightManage.tempTimeSchDetail', {
                url: '/lightManage-tempTimeSchDetail',
                templateUrl: 'app/features/lightManage/tempTimeSchDetail/tempTimeSchDetail/tempTimeSchDetail.html',
                title: '临时方案编辑',
                controller: "tempTimeSchDetailController",
                controllerAs: "vm",
                sidebarMeta: {
                    order: 1000
                }
            });
    }
})();