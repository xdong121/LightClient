(function () {
    'use strict';

    angular.module('Legacy.features.lightManage.tempTimeSchDetail')
        .controller('tempTimeSchDetailController', tempTimeSchDetailController);

    function tempTimeSchDetailController($q, $uibModal, $timeout, tempTimeSchDetailSvc, groupInfoSvc, tools) {
        var vm = this;
        vm.sweetOptions = tools.getSweetOptions();
        vm.search = {};

        vm.load = function () {
            var tempTimeSchDetailPromise = tempTimeSchDetailSvc.crud.query().$promise;
            var enumPromise = tools.getEnums('LightManage');
            var groupInfoPromise = groupInfoSvc.crud.query().$promise;
            console.log(tempTimeSchDetailPromise);
            vm.loadPromise = $q.all([tempTimeSchDetailPromise, enumPromise, groupInfoPromise]).then(function (result) {
                vm.items = result[0];
                vm.enums = result[1];
                vm.groupInfos = result[2];
                console.log(vm.items);
            }, function (res) {
                tools.toastr.error(tools.getError(res));
            });
        };
        vm.load();

        // vm.params = {
        //     pageIndex: 0,
        //     pageSize: 10,
        //     id: null,
        //     startDate1: null,
        //     startDate2: null
        // };
        // vm.load = function (tableState) {
        //     var pagination = tableState.pagination;
        //     var start = pagination.start || 0; // This is NOT the page number, but the index of item in the list that you want to use to display the table.
        //     var pageSize = pagination.number || 10; // Number of entries showed per page.
        //     vm.params = {
        //         pageIndex: start / pageSize,
        //         pageSize: pageSize,
        //         id: vm.search.id,
        //         startDate1: vm.startDate1,
        //         startDate2: vm.startDate2
        //     };
        //     var tempTimeSchDetailPromise = tempTimeSchDetailSvc.BySelect.save(vm.params).$promise;
        //     var enumPromise = tools.getEnums('LightManage');
        //     vm.loadPromise = $q.all([tempTimeSchDetailPromise, enumPromise]).then(function (result) {
        //         vm.items = result[0].data;
        //         pagination.numberOfPages = result[0].pageCount;
        //         vm.enums = result[1];

        //     }, function (res) {
        //         tools.toastr.error(tools.getError(res));
        //     });
        // }
        vm.search = function () {
            vm.hideTable = true;
            $timeout(function () {
                vm.hideTable = false;
            });
        };

        vm.add = function () {
            var addModal = $uibModal.open({
                templateUrl: 'app/features/lightManage/tempTimeSchDetail/tempTimeSchDetail/tempTimeSchDetail.add-modal.html',
                backdrop: false,
                //注入enums, groupInfos
                controller: function ($uibModalInstance, tempTimeSchDetailSvc, enums, groupInfos) {
                    var vm = this;
                    vm.dateTime = new Date();
                    vm.current = {};
                    vm.current.startTime = new Date();
                    vm.current.makeTime = new Date();
                    //接收传过来的变量
                    vm.enums = enums;
                    vm.groupInfos = groupInfos;
                    vm.submitAdd = function () {

                        if (!vm.selectStartTime) {
                            vm.current.startTime = null;
                        }
                        if (!vm.selecTmakeTime) {
                            vm.current.makeTime = null;
                        }
                        vm.current.tempTimeSchMainId = 14;
                        vm.addPromise = tempTimeSchDetailSvc.crud.save(vm.current).$promise
                            .then(function (data) {
                                tools.toastr.success("操作成功");
                                $uibModalInstance.close(data);
                            }, function (res) {
                                tools.toastr.error(tools.getError(res));
                            });
                    };
                },
                controllerAs: 'vm',
                //注入，把load里面的变量传过来。
                resolve: {
                    enums: function () {
                        return vm.enums;
                    },
                    groupInfos: function () {
                        return vm.groupInfos;
                    }
                }
            });
            addModal.result.then(function (item) {
                //alert(item.Result);
                vm.items.push(item);
            }, function () {});
        };

        vm.edit = function (item) {
            var cloned = angular.copy(item);
            var editModal = $uibModal.open({
                templateUrl: 'app/features/lightManage/tempTimeSchDetail/tempTimeSchDetail/tempTimeSchDetail.edit-modal.html',
                backdrop: false,
                //注入enums
                controller: function ($uibModalInstance, tempTimeSchDetailSvc, cloned, enums, groupInfos) {
                    var vm = this;
                    vm.current = cloned;
                    vm.enums = enums;
                    vm.groupInfos = groupInfos;
                    if (vm.current.startTime) {
                        vm.current.startTime = new Date(vm.current.startTime);
                    }
                    if (vm.current.makeTime) {
                        vm.current.makeTime = new Date(vm.current.makeTime);
                    }
                    //重新查询一遍当前选中记录
                    // var tempTimeSchDetailPromise = tempTimeSchDetailSvc.crud.get({
                    //     id: item.id
                    // }).$promise;
                    // var enumPromise = tools.getEnums('LightManage');
                    // vm.loadPromise = $q.all([tempTimeSchDetailPromise, enumPromise]).then(function (result) {
                    //     vm.current = result[0];
                    //     vm.enums = result[1];
                    //     if (vm.current.startTime) {
                    //         vm.current.startTime = new Date(vm.current.startTime);
                    //     }
                    //     if (vm.current.makeTime) {
                    //         vm.current.makeTime = new Date(vm.current.makeTime);
                    //     }
                    // }, function (res) {
                    //     tools.toastr.error(tools.getError(res));
                    // });

                    vm.submitEdit = function () {
                        vm.updatePromise = tempTimeSchDetailSvc.crud.update(vm.current).$promise
                            .then(function (data) {
                                tools.toastr.success("操作成功");
                                $uibModalInstance.close(data);
                            }, function (res) {
                                tools.toastr.error(tools.getError(res));
                            });
                    };
                },
                controllerAs: 'vm',
                resolve: {
                    cloned: function () {
                        return cloned;
                    },
                    enums: function () {
                        return vm.enums;
                    },
                    groupInfos: function () {
                        return vm.groupInfos;
                    }
                }
            });
            editModal.result.then(function (updatedItem) {
                var index = vm.items.indexOf(item);
                if (index > -1) {
                    vm.items[index] = updatedItem;
                }
            }, function () {
                cloned = undefined;
            });
        };

        vm.remove = function (item) {
            vm.deletePromise = tempTimeSchDetailSvc.crud.remove({
                id: item.id
            }).$promise.then(function (data) {
                tools.toastr.success("删除成功");
                var index = vm.items.indexOf(item);
                if (index > -1) {
                    vm.items.splice(index, 1);
                }
            }, function (res) {
                tools.toastr.error(tools.getError(res));
            });
        };
    }

})();