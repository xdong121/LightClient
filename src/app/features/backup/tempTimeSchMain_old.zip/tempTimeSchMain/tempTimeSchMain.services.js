(function () {
    "use strict";

    var moduleId = "Legacy.features.lightManage.tempTimeSchMain.services";
    angular.module(moduleId, ["ngResource"]);

    angular.module(moduleId).factory('tempTimeSchMainSvc', tempTimeSchMainSvc);

    function tempTimeSchMainSvc($resource) {
        return {
            crud: $resource("/api/tempTimeSchMain/:id", {
                id: '@id'
            }, {
                'update': {
                    method: 'PUT'
                },
                'remove': {
                    method: 'DELETE'
                }
            }),
            BySelect: $resource("/api/TempTimeSchMain/BySelect/:obj"),
        };
    }
   

}());