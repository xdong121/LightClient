(function () {
    'use strict';

    angular.module('Legacy.features.lightManage', [
            'Legacy.features.lightManage.dataManage'
        ])
        .config(routeConfig);

    function routeConfig($stateProvider, $urlRouterProvider, baSidebarServiceProvider) {
        $stateProvider
            .state('lightManage', {
                url: '/lightManage',
                abstract: true,
                template: '<div ui-view  autoscroll="true" autoscroll-body-top></div>',
                title: '照明控制系统',
                sidebarMeta: {
                    icon: 'ion-ios-people',
                    order: 2000,
                },

            });

        $urlRouterProvider.otherwise('/dashboard');

        baSidebarServiceProvider.addStaticItem({
            title: '照明控制系统',
            icon: 'ion-ios-people',
            stateRef: 'lightManage',
            subMenu: [{
                stateRef: 'lightManage.dataManage',
                title: '数据',
                disabled: true,
                subMenu: [{
                    stateRef: 'lightManage.dataManage.lightInfo',
                    title: '灯节点信息管理1'
                }]
            }]
        });
    }

})();