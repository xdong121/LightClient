(function () {
    "use strict";

    var moduleId = "Legacy.features.lightManage.dataManage.lightInfo.services";
    angular.module(moduleId, ["ngResource"]);

    angular.module(moduleId).factory('lightInfoSvc', lightInfoSvc);

    function lightInfoSvc($resource) {
        return {
            crud: $resource("/api/lightInfo/:id", {
                id: '@id'
            }, {
                'update': {
                    method: 'PUT'
                },
                'remove': {
                    method: 'DELETE'
                }
            })
        };
    }
   

}());