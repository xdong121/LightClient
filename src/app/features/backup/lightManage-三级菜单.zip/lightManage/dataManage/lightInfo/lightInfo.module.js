(function () {
    'use strict';

    angular.module('Legacy.features.lightManage.dataManage.lightInfo', [
        'Legacy.features.lightManage.dataManage.lightInfo.services'
    ]).config(routeConfig);

    function routeConfig($stateProvider, baSidebarServiceProvider) {
        $stateProvider
            .state('lightManage.dataManage.lightInfo', {
                url: '/lightManage-dataManage-lightInfo',
                templateUrl: 'app/features/lightManage/dataManage/lightInfo/lightInfo/lightInfo.html',
                title: '灯节点信息管理1',
                controller: "lightInfoController",
                controllerAs: "vm",
                sidebarMeta: {
                    order: 0
                }
            });
    }
})();