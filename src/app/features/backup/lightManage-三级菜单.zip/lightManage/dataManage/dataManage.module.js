(function () {
    'use strict';

    angular.module('Legacy.features.lightManage.dataManage', [
        'Legacy.features.lightManage.dataManage.lightInfo'

    ]).config(routeConfig);

    function routeConfig($stateProvider, baSidebarServiceProvider) {
        $stateProvider
            .state('lightManage.dataManage', {
                url: '/lightManage-dataManage',
                abstract: true,
                template: '<div ui-view  autoscroll="true" autoscroll-body-top></div>',
                title: '数据',
                sidebarMeta: {
                    order: 0,
                }           
            });

    }

})();