(function () {
    'use strict';

    angular.module('Legacy.features.lightManage.tempTimeSchMain', [
        'Legacy.features.lightManage.tempTimeSchMain.services'
    ]).config(routeConfig);

    function routeConfig($stateProvider, baSidebarServiceProvider) {
        $stateProvider
            .state('lightManage.tempTimeSchMain', {
                url: '/lightManage-tempTimeSchMain',
                templateUrl: 'app/features/lightManage/tempTimeSchMain/tempTimeSchMain/tempTimeSchMain.html',
                title: '临时方案设置',
                controller: "tempTimeSchMainController",
                controllerAs: "vm",
                sidebarMeta: {
                    order: 1000
                }
            });
    }
})();