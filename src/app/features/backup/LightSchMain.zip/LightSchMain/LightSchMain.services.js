(function () {
    "use strict";

    var moduleId = "Legacy.features.lightManage.LightSchMain.services";
    angular.module(moduleId, ["ngResource"]);

    angular.module(moduleId).factory('LightSchMainSvc', LightSchMainSvc);

    function LightSchMainSvc($resource) {
        return {
            crud: $resource("/api/LightSchMain/:id", {
                id: '@id'
            }, {
                'update': {
                    method: 'PUT'
                },
                'remove': {
                    method: 'DELETE'
                }
            }),
            BySelect: $resource("/api/LightSchMain/BySelect/:obj"),
           
        };
    }
   

}());